TERMUX_PKG_HOMEPAGE=https://github.com/facebookincubator/fastmod
TERMUX_PKG_DESCRIPTION="Regex-based code refactoring utility"
TERMUX_PKG_LICENSE="Apache-2.0"
TERMUX_PKG_MAINTAINER="Leonid Plyushch <leonid.plyushch@gmail.com>"
TERMUX_PKG_VERSION=0.3.0
TERMUX_PKG_SRCURL=https://github.com/facebookincubator/fastmod/archive/v$TERMUX_PKG_VERSION.tar.gz
TERMUX_PKG_SHA256=95925c73d06f6bd9ea9a6ca66c847e9722fe7bff5c8c3ee9a3245a37f630dfc0
TERMUX_PKG_BUILD_IN_SRC=true
