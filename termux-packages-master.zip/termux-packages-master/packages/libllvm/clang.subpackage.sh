TERMUX_SUBPKG_INCLUDE="
bin/c++
bin/cc
bin/*clang*
bin/*cpp
bin/*g++
bin/*gcc
bin/scan-build
lib/clang
lib/libomp.a
libexec/
share/clang
share/man/man1/scan-build.1
"
TERMUX_SUBPKG_DESCRIPTION="C language frontend for LLVM"
