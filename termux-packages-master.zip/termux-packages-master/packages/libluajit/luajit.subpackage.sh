TERMUX_SUBPKG_INCLUDE="bin/luajit share/man/man1 $TERMUX_LUAJIT_JIT_FOLDER_RELATIVE"
TERMUX_SUBPKG_DESCRIPTION="Just-In-Time compiler for Lua - command line tool"
