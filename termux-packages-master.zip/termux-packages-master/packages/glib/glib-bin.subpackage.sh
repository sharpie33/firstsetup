TERMUX_SUBPKG_INCLUDE="share/bash-completion/ share/man/man1/ bin/"
TERMUX_SUBPKG_DESCRIPTION="Programs for the GLib library"
