TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="Tools for working with bzip2 compression"
TERMUX_SUBPKG_ESSENTIAL=true
