TERMUX_SUBPKG_DESCRIPTION="A geoip lookup utility for MaxMind DB"
TERMUX_SUBPKG_DEPENDS="geoip2-database"

TERMUX_SUBPKG_INCLUDE="
bin/mmdblookup
share/man/man1/mmdblookup.1"
