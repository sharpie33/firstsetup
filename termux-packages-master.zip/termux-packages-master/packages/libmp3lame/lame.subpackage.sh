TERMUX_SUBPKG_INCLUDE="bin share/doc/lame share/man"
TERMUX_SUBPKG_DESCRIPTION="High quality MPEG Audio Layer III (MP3) encoder - frontend"
TERMUX_SUBPKG_DEPENDS=ncurses
