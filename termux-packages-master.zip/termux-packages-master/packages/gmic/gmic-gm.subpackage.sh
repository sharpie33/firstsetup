TERMUX_SUBPKG_INCLUDE="bin/gmic-gm share/man/man1/gmic-gm.1.gz"
TERMUX_SUBPKG_DESCRIPTION="Full-featured framework for image processing (GraphicsMagick variant)"
TERMUX_SUBPKG_DEPENDS="graphicsmagick"
TERMUX_SUBPKG_DEPEND_ON_PARENT=deps
